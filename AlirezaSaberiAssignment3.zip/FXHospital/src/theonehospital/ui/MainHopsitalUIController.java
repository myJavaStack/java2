/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theonehospital.ui;

import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import theonehospital.business.HospitalRecordsManager;
import theonehospital.data.Inpatient;
import theonehospital.data.Medication;
import theonehospital.data.Patient;

/**
 * FXML Controller class
 *
 * @author zohre_000
 */
public class MainHopsitalUIController implements Initializable {

    private HospitalRecordsManager hospitalRecordsManager;
    private ObservableList<Patient> personData = FXCollections.observableArrayList();
    private ObservableList<Medication> medicationData = FXCollections.observableArrayList();
    private ObservableList<Inpatient> inpatientData = FXCollections.observableArrayList();
    
    @FXML
    private TableView<Patient> patientTable;

    @FXML
    private TableColumn<Patient, Integer> patientID;
    @FXML
    private TableColumn<Patient, String> firstName;
    @FXML
    private TableColumn<Patient, String> lastName;
    @FXML
    private TableColumn<Patient, String> diagnosis;
    @FXML
    private TableColumn<Patient, String> releaseDate;
  
    
    @FXML
    private TextField patientIDLabel;
    @FXML
    private TextField firstNameLabel;
    @FXML
    private TextField lastNameLabel;
    @FXML
    private TextField diagnosisLabel;
    @FXML
    private TextField releaseDateLabel;
    
    @FXML 
    private javafx.scene.control.Button closeButton;
    
    @FXML
    private void handleShowAllPatients(ActionEvent event) {
        personData = hospitalRecordsManager.hospitalDBCRUDHandler.FindAllPatients();
        patientTable.setItems(personData);
    }
    
    @FXML
    private void handleClearForm(ActionEvent event) {
        showPatientDetails(null);
    }
    
    @FXML
    private void handleFindPatient(ActionEvent event) {
        if(patientIDLabel.getText() != null && patientIDLabel.getText().length() != 0){
            Patient patient = hospitalRecordsManager.hospitalDBCRUDHandler.FindPatientByID(Integer.parseInt(patientIDLabel.getText()));
            personData.clear();
            personData.add(patient);
        } else if (lastNameLabel.getText() != null && lastNameLabel.getText().length() != 0){
        
            Patient patient = hospitalRecordsManager.hospitalDBCRUDHandler.FindPatientByLastName(lastNameLabel.getText());
            personData.clear();
            personData.add(patient);
        } else {
            personData.clear();
        }

    }
    
    @FXML
    private void handleSave(ActionEvent event) {
        if(patientIDLabel.getText() == null || patientIDLabel.getText().length() == 0){

            try {
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
                
                Patient patient = hospitalRecordsManager.hospitalDBCRUDHandler.CreatePatient(lastNameLabel.getText().toString(), firstNameLabel.getText().toString(),
                        diagnosisLabel.getText().toString(), 
                        formatter.parse(releaseDateLabel.getText().toString()), formatter.parse(releaseDateLabel.getText().toString()));
                personData.add(patient);
            } catch (ParseException ex) {
                Logger.getLogger(MainHopsitalUIController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
        
            hospitalRecordsManager.hospitalDBCRUDHandler.UpdatePatientsDiagnosis(Integer.parseInt(patientIDLabel.getText().toString()), 
                    diagnosisLabel.getText().toString());
            FXCollections.copy(personData, hospitalRecordsManager.hospitalDBCRUDHandler.FindAllPatients());

        } 

    }
    
    @FXML
    private void handleDelete(ActionEvent event) {
        if(lastNameLabel.getText() != null && lastNameLabel.getText().length() != 0){
            hospitalRecordsManager.hospitalDBCRUDHandler.DeletePatient(lastNameLabel.getText());
            personData = hospitalRecordsManager.hospitalDBCRUDHandler.FindAllPatients();
        }
    }
    
    @FXML
        private void handleCloseApp(ActionEvent event) {
        Stage stage = (Stage) closeButton.getScene().getWindow();
    
        stage.close();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        hospitalRecordsManager = new HospitalRecordsManager();
        
        patientID.setCellValueFactory(new PropertyValueFactory<Patient, Integer>("patientID"));
        firstName.setCellValueFactory(new PropertyValueFactory<Patient, String>("firstName"));
        lastName.setCellValueFactory(new PropertyValueFactory<Patient, String>("lastName"));
        diagnosis.setCellValueFactory(new PropertyValueFactory<Patient, String>("diagnosis"));
        releaseDate.setCellValueFactory(new PropertyValueFactory<Patient, String>("releaseDate"));
        
        patientTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> showPatientDetails(newValue));
    }    
    
    
    private void showPatientDetails(Patient person) {
    if (person != null) {

        patientIDLabel.setText(Integer.toString(person.getPatientID()));
        firstNameLabel.setText(person.getFirstName());
        lastNameLabel.setText(person.getLastName());
        diagnosisLabel.setText(person.getDiagnosis());
        releaseDateLabel.setText(person.getReleaseDate().toString());
    } else {
        patientIDLabel.setText("");
        firstNameLabel.setText("");
        lastNameLabel.setText("");
        diagnosisLabel.setText("");
        releaseDateLabel.setText("");
    }
}
    
}
