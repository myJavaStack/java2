/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theonehospital.business;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import theonehospital.data.Inpatient;
import theonehospital.data.Medication;
import theonehospital.data.Patient;
import theonehospital.data.Surgical;

/**
 *
 * @author alans
 */
public class HospitalRecordsManager {

    static final String DB_URL = "jdbc:derby://localhost:1527/HOSPITALDB";

    //  Database credentials
    static final String USERNAME = "hospital";
    static final String PASSWORD = "hospital";
    
    private  Connection conn = null;
    public HospitalDBCRUDHandler hospitalDBCRUDHandler;

    public HospitalRecordsManager() {
        connectToDB();
        hospitalDBCRUDHandler = new HospitalDBCRUDHandler(conn);
    }

    private void connectToDB() {
        try {
            //STEP 3: Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
        } catch (SQLException ex) {
            Logger.getLogger(HospitalRecordsManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void printAllPatientsInfo(){
        List<Patient> patients = hospitalDBCRUDHandler.FindAllPatients();
        for(Patient p : patients){
            printMasterRecord(p);
        }
    }
    
    public void printAllInpatients(){
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT dateOfStay, roomNumber, dailyRate, \n" +
"            supplies, services, patientID FROM inpatient";
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                //Retrieve by column name
                Date date = rs.getDate("dateOfStay");
                String roomNumber = rs.getString("roomNumber");
                double dailyRate = rs.getDouble("dailyRate");
                double supplies = rs.getDouble("supplies");
                double services = rs.getDouble("services");
                int patientID = rs.getInt("patientid");


                //Display values
                System.out.print("Date of Stay: " + date);
                System.out.print(", Room number: " + roomNumber);
                System.out.print(", DailyRate: " + dailyRate);
                System.out.print(", Supplies: " + supplies);
                System.out.print(", Services: " + services);
                System.out.println(", Patient ID: " + patientID);
            }
            
            System.out.println();
            // Clean-up environment
            rs.close();
            stmt.close();

        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } 
    }

    public void printAllSurgical(){
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT dateOfSurgery, surgery, roomfee, \n" +
"            supplies, patientID FROM surgical";
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                //Retrieve by column name
                Date date = rs.getDate("dateOfSurgery");
                String surgery = rs.getString("surgery");
                double roomFee = rs.getDouble("roomfee");
                double supplies = rs.getDouble("supplies");
                int patientID = rs.getInt("patientid");


                //Display values
                System.out.print("Date of Surgery: " + date);
                System.out.print(", surgery: " + surgery);
                System.out.print(", Room fee: " + roomFee);
                System.out.print(", Supplies: " + supplies);
                System.out.println(", Patient ID: " + patientID);
            }
            // Clean-up environment
            rs.close();
            stmt.close();

        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } 
    }
    
    public void printAllMedications(){
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT dateOfMed, med, unitcost, \n" +
"            units, patientID FROM medication";
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                //Retrieve by column name
                Date date = rs.getDate("dateOfMed");
                String med = rs.getString("med");
                double unitCost = rs.getDouble("unitcost");
                double cost = rs.getDouble("units");
                int patientID = rs.getInt("patientid");


                //Display values
                System.out.print("Date of medication: " + date);
                System.out.print(", Medication: " + med);
                System.out.print(", Unit cost: " + unitCost);
                System.out.print(", Units: " + cost);
                System.out.println(", Patient ID: " + patientID);
            }
            // Clean-up environment
            rs.close();
            stmt.close();

        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } 
    }
    
    public void printMasterRecordByID(int patientID){
        Patient patient = hospitalDBCRUDHandler.FindPatientByID(patientID);
        System.out.println("**** Printing master info by patient ID: ");
        printMasterRecord(patient);
    }
    
    public void printMasterRecordByLastName(String lastname){
        Patient patient = hospitalDBCRUDHandler.FindPatientByLastName(lastname);
        System.out.println("**** Printing master info by last name: ");
        printMasterRecord(patient);
    }
    
    private void printMasterRecord(Patient patient){
        
        System.out.print("Patient ID: " + patient.getPatientID());
        System.out.print(", First name: " + patient.getFirstName());
        System.out.print(", Last name : " + patient.getLastName());
        System.out.print(", Diagnosis: " + patient.getDiagnosis());
        System.out.print(", Admission date: " + patient.getAdmissionDate());
        System.out.println(" Release date: " + patient.getReleaseDate());

        System.out.println("  **** Printing inpatients: ");
        for(Inpatient inp : patient.getInpatientList()){
            
            System.out.print("      Date of Stay: " + inp.getDateOfStay());
            System.out.print(", Room number: " + inp.getRoomNumber());
            System.out.print(", DailyRate: " + inp.getDailyRate());
            System.out.print(", Supplies: " + inp.getSupplies());
            System.out.println(", Services: " + inp.getServices());
        }
        
        System.out.println("  **** Printing surgeries: ");
        for(Surgical surg : patient.getSurgicalList()){
            System.out.print("      Date of Surgery: " + surg.getDateOfSurgery());
            System.out.print(", surgery: " + surg.getSurgery());
            System.out.print(", Room fee: " + surg.getRoomFee());
            System.out.println(", Supplies: " + surg.getSupplies());
        }
        
        System.out.println("  **** Printing medications: ");
        for(Medication med : patient.getMedList()){
            System.out.print("      Date of medication: " + med.getDateOfMed());
            System.out.print(", Medication: " + med.getMed());
            System.out.print(", Unit cost: " + med.getUnitCost());
            System.out.println(", Units: " + med.getUnits());
        }
        System.out.println();
    }
    
    
}
