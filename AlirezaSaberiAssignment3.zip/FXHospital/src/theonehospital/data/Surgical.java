/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theonehospital.data;

import java.util.Date;

/**
 *
 * @author alans
 */
public class Surgical {

    public Surgical(Date _dateOfSurgery, String _surgery, double _roomFee, double _supplies, int _pationtID) {
        this._dateOfSurgery = _dateOfSurgery;
        this._surgery = _surgery;
        this._roomFee = _roomFee;
        this._supplies = _supplies;
        this._patientID = _pationtID;
    }

    @Override
    public boolean equals(Object obj){
        if (obj == null) return false;
        if (obj == this) return true;
        if (!(obj instanceof Surgical))return false;

        final Surgical other = (Surgical) obj;
        if(other._dateOfSurgery.getDate() != _dateOfSurgery.getDate()
                || !other._surgery.equalsIgnoreCase(_surgery)
                || other._roomFee != _roomFee || other._supplies != _supplies || other._patientID != _patientID){
            return false;
        }
        return true;
    }
    
    /**
     * @return the _dateOfSurgery
     */
    public Date getDateOfSurgery() {
        return _dateOfSurgery;
    }

    /**
     * @param _dateOfSurgery the _dateOfSurgery to set
     */
    public void setDateOfSurgery(Date _dateOfSurgery) {
        this._dateOfSurgery = _dateOfSurgery;
    }

    /**
     * @return the _surgery
     */
    public String getSurgery() {
        return _surgery;
    }

    /**
     * @param _surgery the _surgery to set
     */
    public void setSurgery(String _surgery) {
        this._surgery = _surgery;
    }

    /**
     * @return the _roomFee
     */
    public double getRoomFee() {
        return _roomFee;
    }

    /**
     * @param _roomFee the _roomFee to set
     */
    public void setRoomFee(double _roomFee) {
        this._roomFee = _roomFee;
    }

    /**
     * @return the _supplies
     */
    public double getSupplies() {
        return _supplies;
    }

    /**
     * @param _supplies the _supplies to set
     */
    public void setSupplies(double _supplies) {
        this._supplies = _supplies;
    }

    /**
     * @return the _patientID
     */
    public int getPatientID() {
        return _patientID;
    }

    /**
     * @param _patientID the _patientID to set
     */
    public void setPatientID(int _patientID) {
        this._patientID = _patientID;
    }
   private Date _dateOfSurgery;
   private String _surgery;
   private double _roomFee;
   private double _supplies;
   private int _patientID;
   
}
