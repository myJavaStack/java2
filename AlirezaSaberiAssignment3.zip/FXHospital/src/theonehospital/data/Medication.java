/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theonehospital.data;

import java.util.Date;

/**
 *
 * @author alans
 */
public class Medication {

    public Medication(Date _dateOfMed, String _Med, double _unitCost, double _units, int _patientID) {
        this._dateOfMed = _dateOfMed;
        this._Med = _Med;
        this._unitCost = _unitCost;
        this._units = _units;
        this._patientID = _patientID;
    }

    @Override
    public boolean equals(Object obj){
        if (obj == null) return false;
        if (obj == this) return true;
        if (!(obj instanceof Medication))return false;

        final Medication other = (Medication) obj;
        if(other._dateOfMed.getDate() != _dateOfMed.getDate()
                || !other._Med.equalsIgnoreCase(_Med)
                || other._unitCost != _unitCost || other._units != _units || other._patientID != _patientID){
            return false;
        }
        return true;
    }
    
    /**
     * @return the _dateOfMed
     */
    public Date getDateOfMed() {
        return _dateOfMed;
    }

    /**
     * @param _dateOfMed the _dateOfMed to set
     */
    public void setDateOfMed(Date _dateOfMed) {
        this._dateOfMed = _dateOfMed;
    }

    /**
     * @return the _Med
     */
    public String getMed() {
        return _Med;
    }

    /**
     * @param _Med the _Med to set
     */
    public void setMed(String _Med) {
        this._Med = _Med;
    }

    /**
     * @return the _unitCost
     */
    public double getUnitCost() {
        return _unitCost;
    }

    /**
     * @param _unitCost the _unitCost to set
     */
    public void setUnitCost(double _unitCost) {
        this._unitCost = _unitCost;
    }

    /**
     * @return the _units
     */
    public double getUnits() {
        return _units;
    }

    /**
     * @param _units 
     */
    public void setUnits(double units) {
        this._units = units;
    }

    /**
     * @return the _patientID
     */
    public int getPatientID() {
        return _patientID;
    }

    /**
     * @param _patientID the _patientID to set
     */
    public void setPatientID(int _patientID) {
        this._patientID = _patientID;
    }
    private Date _dateOfMed;
    private String _Med;
    private double _unitCost;
    private double _units;
    private int _patientID;
}
