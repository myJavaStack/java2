/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theonehospital.business;

import com.sun.javafx.scene.control.skin.VirtualFlow;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import theonehospital.data.Inpatient;
import theonehospital.data.Medication;
import theonehospital.data.Patient;
import theonehospital.data.Surgical;

/**
 *
 * @author alans
 */
public class HospitalDBCRUDHandler {

    private Connection _dbConnection = null;
    
    public HospitalDBCRUDHandler(Connection conn) {
        _dbConnection = conn;
    }
    
    //================================================================================
    // Patient CRUD
    //================================================================================

    public Patient CreatePatient(String lastName, String firstName, String diagnosis, 
        Date admissionDate, Date releaseDate){
        PreparedStatement preparedStmt = null;
        try {
            String sql = " insert into patient (lastname, firstname, diagnosis, admissiondate, releasedate)"
            + " values (?, ?, ?, ?, ?)";
            preparedStmt = _dbConnection.prepareStatement(sql);
            preparedStmt.setString (1, lastName);
            preparedStmt.setString   (2, firstName);
            preparedStmt.setString(3, diagnosis);
            preparedStmt.setDate(4, new java.sql.Date(admissionDate.getTime()));
            preparedStmt.setDate(5, new java.sql.Date(releaseDate.getTime()));
            preparedStmt.execute();
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        int id = FindPatientByLastName(lastName).getPatientID();
        Patient newPatient = new Patient(lastName, firstName, diagnosis, admissionDate, releaseDate);
        newPatient.setPatientID(id);
        return newPatient;
    }
 
    public void DeletePatient(String lastName){
    
        PreparedStatement preparedStmt = null;
        try {
            Patient p = FindPatientByLastName(lastName);
            
            if(p != null){
                String deleteSQL = "delete from patient WHERE lastname = ?";
                preparedStmt = _dbConnection.prepareStatement(deleteSQL);
                preparedStmt.setString(1, lastName);
                preparedStmt.executeUpdate();

                String deleteMedSql = "delete from medication WHERE patientID = ?";
                preparedStmt = _dbConnection.prepareStatement(deleteMedSql);
                preparedStmt.setInt(1, p.getPatientID());
                preparedStmt.executeUpdate();

                String deleteInpatientSql = "delete from inpatient WHERE patientID = ?";
                preparedStmt = _dbConnection.prepareStatement(deleteInpatientSql);
                preparedStmt.setInt(1, p.getPatientID());
                preparedStmt.executeUpdate();

                String deleteSurgicalSql = "delete from surgical WHERE patientID = ?";
                preparedStmt = _dbConnection.prepareStatement(deleteSurgicalSql);
                preparedStmt.setInt(1, p.getPatientID());
                preparedStmt.executeUpdate();
            
                preparedStmt.close();
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public List<Patient> FindAllPatients(){
        
        List<Patient> patientList = new ArrayList<Patient>();
        
        String sql = "select * from patient";
        PreparedStatement preparedStmt = null;
        try {
            preparedStmt = _dbConnection.prepareStatement(sql);

            ResultSet rs = preparedStmt.executeQuery();
            while (rs.next()) {
                Patient patient = new Patient(rs.getString("lastname"), rs.getString("firstname"), 
                        rs.getString("diagnosis"), rs.getDate("admissiondate"), rs.getDate("releasedate"));
                patient.setPatientID(rs.getInt("patientID"));
                setRecordDetails(patient, patient.getPatientID());
                patientList.add(patient);
            }
         
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return patientList;
    }
    
    public Patient FindPatientByID(int patientID){
        
        Patient patient = null;
        String sql = "select lastname, firstname, diagnosis, admissiondate, releasedate"
                + " from patient where patientid = ?";
        PreparedStatement preparedStmt = null;
        try {
            preparedStmt = _dbConnection.prepareStatement(sql);
            preparedStmt.setInt (1, patientID);

            ResultSet rs = preparedStmt.executeQuery();
            if (rs.next()) {
                patient = new Patient(rs.getString("lastname"), rs.getString("firstname"), 
                        rs.getString("diagnosis"), rs.getDate("admissiondate"), rs.getDate("releasedate"));
                patient.setPatientID(patientID);
                setRecordDetails(patient, patientID);
            }
            
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return patient;
    }

    private void setRecordDetails(Patient patient, int patientID) {
        if(patient != null){
            List<Inpatient> inpatients = FindInpatientByPatientID(patientID);
            if(inpatients != null && inpatients.size() > 0){
                patient.setInpatientList(inpatients);
            }
            
            List<Surgical> surgicals = FindSurgicalByPatientID(patientID);
            if(surgicals != null && surgicals.size() > 0){
                patient.setSurgicalList(surgicals);
            }
            
            List<Medication> medList = FindMedicationByPatientID(patientID);
            if(medList != null && medList.size() > 0){
                patient.setMedList(medList);
            }
        }
    }
    
    public Patient FindPatientByLastName(String lastName){
        
        Patient patient = null;
        String sql = "select patientid, lastname, firstname, diagnosis, admissiondate, releasedate"
                + " from patient where lastname = ?";
        PreparedStatement preparedStmt = null;
        try {
            preparedStmt = _dbConnection.prepareStatement(sql);
            preparedStmt.setString(1, lastName);
            
            ResultSet rs = preparedStmt.executeQuery();
            if (rs.next()) {
                patient = new Patient(rs.getString("lastname"), rs.getString("firstname"), 
                        rs.getString("diagnosis"), rs.getDate("admissiondate"), rs.getDate("releasedate"));
                patient.setPatientID(rs.getInt("patientID"));
                setRecordDetails(patient, patient.getPatientID());
            }
           
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return patient;
    }

    public void UpdatePatientsDiagnosis(int patientID, String newDiagnosis){
        try {
            String updateTableSQL = "UPDATE patient SET diagnosis = ? WHERE patientID = ?";
            PreparedStatement preparedStmt  = _dbConnection.prepareStatement(updateTableSQL);

            preparedStmt.setString(1, newDiagnosis);
            preparedStmt.setInt(2, patientID);
            
            preparedStmt.executeUpdate();
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }
    
    public void UpdatePatientsReleaseDate(int patientID, Date newReleaseDate){
        try {
            String updateTableSQL = "UPDATE patient SET releasedate = ? WHERE patientID = ?";
            PreparedStatement preparedStmt  = _dbConnection.prepareStatement(updateTableSQL);

            preparedStmt.setDate(1, new java.sql.Date(newReleaseDate.getTime()));
            preparedStmt.setInt(2, patientID);
            
            preparedStmt.executeUpdate();
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }
    
    //================================================================================
    // Inpatient CRUD
    //================================================================================

    public Inpatient CreateInpatient(Date dateOfStay, String roomNumber, double dailyRate, 
            double supplies, double services, int patientID){
        PreparedStatement preparedStmt = null;
        
        // if a master record does not exist (no patient with that ID), return null
        if(FindPatientByID(patientID) == null){
            return null;
        }
        
        try {
            String sql = " insert into inpatient (dateOfStay, roomNumber, dailyRate, \n" +
"            supplies, services, patientID)"
            + " values (?, ?, ?, ?, ?, ?)";
            preparedStmt = _dbConnection.prepareStatement(sql);
            preparedStmt.setDate (1, new java.sql.Date(dateOfStay.getTime()));
            preparedStmt.setString   (2, roomNumber);
            preparedStmt.setDouble(3, dailyRate);
            preparedStmt.setDouble(4, supplies);
            preparedStmt.setDouble(5, services);
            preparedStmt.setInt(6, patientID);
            
            preparedStmt.execute();
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return new Inpatient(dateOfStay, roomNumber, dailyRate, supplies, services, patientID);
    }
    
    public void UpdateInpatient(Date dateOfStay, String roomNumber, double dailyRate, 
            double supplies, double services, int patientID){
        try {
            String updateTableSQL = "UPDATE inpatient SET dateOfStay = ?, dailyRate = ?, supplies = ?, services = ?, roomnumber = ? "
                    + "WHERE patientID = ?";
            PreparedStatement preparedStmt  = _dbConnection.prepareStatement(updateTableSQL);

            preparedStmt.setDate(1, new java.sql.Date(dateOfStay.getTime()));
            preparedStmt.setDouble(2, dailyRate);
            preparedStmt.setDouble(3, supplies);
            preparedStmt.setDouble(4, services);
            preparedStmt.setString(5, roomNumber);
            preparedStmt.setInt(6, patientID);
            
            preparedStmt.executeUpdate();
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }
    
    public List<Inpatient> FindInpatientByPatientID(int patientID){
        
        List<Inpatient> resultList = new ArrayList<Inpatient>();
        
        String sql = "select dateOfStay, roomNumber, dailyRate, \n" +
"            supplies, services, patientID"
                + " from inpatient where patientid = ?";
        PreparedStatement preparedStmt = null;
        try {
            preparedStmt = _dbConnection.prepareStatement(sql);
            preparedStmt.setInt (1, patientID);

            ResultSet rs = preparedStmt.executeQuery();
            while (rs.next()) {
                resultList.add(new Inpatient(rs.getDate("dateOfStay"), rs.getString("roomNumber"), 
                    rs.getDouble("dailyRate"), rs.getDouble("supplies"), rs.getDouble("services"), 
                        rs.getInt("patientID")));
            }

            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return resultList;
    }
    
    public void DeleteInpatient(int patientID, String roomNumber){
    
        PreparedStatement preparedStmt = null;
        try {
          
            String deleteSQL = "delete from inpatient WHERE patientID = ? AND roomNumber = ?";
            preparedStmt = _dbConnection.prepareStatement(deleteSQL);
            preparedStmt.setInt(1, patientID);
            preparedStmt.setString(2, roomNumber);
            
            preparedStmt.executeUpdate();
       
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public List<Inpatient> FindAllInpatients(){
        
        List<Inpatient> patientList = new ArrayList<Inpatient>();
        Statement stmt = null;
        try {
            stmt = _dbConnection.createStatement();
            String sql = "select * from inpatient";
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Inpatient inpatient = new Inpatient(rs.getDate("dateOfStay"), rs.getString("roomNumber"), 
                        rs.getDouble("dailyRate"), rs.getDouble("supplies"), rs.getDouble("services"), rs.getInt("patientID"));
                patientList.add(inpatient);
            }
         
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return patientList;
    }
    
    //================================================================================
    // Surgical CRUD
    //================================================================================

    public Surgical CreateSurgical(Date dateOfSurgery, String surgery, double roomFee, double supplies, int patientID){
        PreparedStatement preparedStmt = null;
        
        // if a master record does not exist (no patient with that ID), return null
        if(FindPatientByID(patientID) == null){
            return null;
        }
        
        try {
            String sql = " insert into surgical (dateOfSurgery, surgery, roomfee, \n" +
"            supplies, patientID)"
            + " values (?, ?, ?, ?, ?)";
            preparedStmt = _dbConnection.prepareStatement(sql);
            preparedStmt.setDate (1, new java.sql.Date(dateOfSurgery.getTime()));
            preparedStmt.setString   (2, surgery);
            preparedStmt.setDouble(3, roomFee);
            preparedStmt.setDouble(4, supplies);
            preparedStmt.setInt(5, patientID);
            
            preparedStmt.execute();
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return new Surgical(dateOfSurgery, surgery, roomFee, supplies, patientID);
    }
    
    public void DeleteSurgical(int patientID, String surgery){
    
        PreparedStatement preparedStmt = null;
        try {
          
            String deleteSQL = "delete from surgical WHERE patientID = ? AND surgery = ?";
            preparedStmt = _dbConnection.prepareStatement(deleteSQL);
            preparedStmt.setInt(1, patientID);
            preparedStmt.setString(2, surgery);
            
            preparedStmt.executeUpdate();
       
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public void UpdateSurgery(Date dateOfSurgery, String surgery, double roomFee, double supplies, int patientID){
        try {
            String updateTableSQL = "UPDATE surgical SET dateOfSurgery = ?, roomfee = ?, supplies = ?, surgery = ? "
                    + "WHERE patientID = ?";
            PreparedStatement preparedStmt  = _dbConnection.prepareStatement(updateTableSQL);

            preparedStmt.setDate(1, new java.sql.Date(dateOfSurgery.getTime()));
            preparedStmt.setDouble(2, roomFee);
            preparedStmt.setDouble(3, supplies);
            preparedStmt.setString(4, surgery);
            preparedStmt.setInt(5, patientID);
            
            preparedStmt.executeUpdate();
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }
    
    public List<Surgical> FindSurgicalByPatientID(int patientID){
        
        List<Surgical> resultList = new ArrayList<Surgical>();
        
        String sql = "select dateOfSurgery, surgery, roomfee, \n" +
"            supplies, patientID"
                + " from surgical where patientid = ?";
        PreparedStatement preparedStmt = null;
        try {
            preparedStmt = _dbConnection.prepareStatement(sql);
            preparedStmt.setInt (1, patientID);

            ResultSet rs = preparedStmt.executeQuery();
            while (rs.next()) {
                resultList.add(new Surgical(rs.getDate("dateOfSurgery"), rs.getString("surgery"), 
                    rs.getDouble("roomfee"), rs.getDouble("supplies"), rs.getInt("patientID")));
            }

            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return resultList;
    }
    
    public List<Surgical> FindAllSurgicals(){
        
        List<Surgical> surgeryList = new ArrayList<Surgical>();
        Statement stmt = null;
        try {
            stmt = _dbConnection.createStatement();
            String sql = "select * from surgical";
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Surgical surgery = new Surgical(rs.getDate("dateOfSurgery"), rs.getString("surgery"), 
                    rs.getDouble("roomfee"), rs.getDouble("supplies"), rs.getInt("patientID"));
                surgeryList.add(surgery);
            }
         
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return surgeryList;
    }
    
    //================================================================================
    // Medication CRUD
    //================================================================================

    public Medication CreateMedication(Date dateOfMed, String med, double unitCost, double units, int patientID){
        PreparedStatement preparedStmt = null;
        
        // if a master record does not exist (no patient with that ID), return null
        if(FindPatientByID(patientID) == null){
            return null;
        }
        try {
            String sql = " insert into medication (dateOfMed, med, unitcost, \n" +
"            units, patientID)"
            + " values (?, ?, ?, ?, ?)";
            preparedStmt = _dbConnection.prepareStatement(sql);
            preparedStmt.setDate (1, new java.sql.Date(dateOfMed.getTime()));
            preparedStmt.setString   (2, med);
            preparedStmt.setDouble(3, unitCost);
            preparedStmt.setDouble(4, units);
            preparedStmt.setInt(5, patientID);
            
            preparedStmt.execute();
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return new Medication(dateOfMed, med, unitCost, units, patientID);
    }
    
    public void UpdateMedication(Date dateOfMed, String med, double unitCost, double units, int patientID){
        try {
            String updateTableSQL = "UPDATE medication SET dateOfMed = ?, unitcost = ?, units = ?, med = ? "
                    + "WHERE patientID = ?";
            PreparedStatement preparedStmt  = _dbConnection.prepareStatement(updateTableSQL);

            preparedStmt.setDate(1, new java.sql.Date(dateOfMed.getTime()));
            preparedStmt.setDouble(2, unitCost);
            preparedStmt.setDouble(3, units);
            preparedStmt.setString(4, med);
            preparedStmt.setInt(5, patientID);
            
            preparedStmt.executeUpdate();
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }
    
     public void DeleteMedication(int patientID, String med){
    
        PreparedStatement preparedStmt = null;
        try {
          
            String deleteSQL = "delete from medication WHERE patientID = ? AND med = ?";
            preparedStmt = _dbConnection.prepareStatement(deleteSQL);
            preparedStmt.setInt(1, patientID);
            preparedStmt.setString(2, med);
            
            preparedStmt.executeUpdate();
       
            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public List<Medication> FindMedicationByPatientID(int patientID){
        
        List<Medication> resultList = new ArrayList<Medication>();
        
        String sql = "select dateOfMed, med, unitcost, \n" +
"            units, patientID"
                + " from medication where patientid = ?";
        PreparedStatement preparedStmt = null;
        try {
            preparedStmt = _dbConnection.prepareStatement(sql);
            preparedStmt.setInt (1, patientID);

            ResultSet rs = preparedStmt.executeQuery();
            while (rs.next()) {
                resultList.add(new Medication(rs.getDate("dateOfMed"), rs.getString("med"), 
                    rs.getDouble("unitcost"), rs.getDouble("units"), rs.getInt("patientID")));
            }

            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return resultList;
    }
    
    public List<Medication> FindAllMedications(){
        
        List<Medication> medicationList = new ArrayList<Medication>();
        Statement stmt = null;
        try {
            stmt = _dbConnection.createStatement();
            String sql = "select * from medication";
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Medication medication = new Medication(rs.getDate("dateOfMed"), rs.getString("med"), 
                    rs.getDouble("unitcost"), rs.getDouble("units"), rs.getInt("patientID"));
                medicationList.add(medication);
            }
         
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(HospitalDBCRUDHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return medicationList;
    }
}
