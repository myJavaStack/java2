/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theonehospital.data;

import java.util.Date;

/**
 *
 * @author alans
 */
public class Inpatient {

    public Inpatient(Date _dateOfStay, String _roomNumber, double _dailyRate, double _supplies, double _services, int _patientID) {
        this._dateOfStay = _dateOfStay;
        this._roomNumber = _roomNumber;
        this._dailyRate = _dailyRate;
        this._supplies = _supplies;
        this._services = _services;
        this._patientID = _patientID;
    }

    @Override
    public boolean equals(Object obj){
        if (obj == null) return false;
        if (obj == this) return true;
        if (!(obj instanceof Inpatient))return false;

        final Inpatient other = (Inpatient) obj;
        if(!other.getRoomNumber().equalsIgnoreCase(this.getRoomNumber()) 
                || other._dateOfStay.getDate() != _dateOfStay.getDate()
                || other._dailyRate != _dailyRate
                || other._services != _services || other._supplies != _supplies || other._patientID != _patientID){
            return false;
        }
        return true;
    }
    
    /**
     * @return the _dateOfStay
     */
    public Date getDateOfStay() {
        return _dateOfStay;
    }

    /**
     * @param _dateOfStay the _dateOfStay to set
     */
    public void setDateOfStay(Date _dateOfStay) {
        this._dateOfStay = _dateOfStay;
    }

    /**
     * @return the _roomNumber
     */
    public String getRoomNumber() {
        return _roomNumber;
    }

    /**
     * @param _roomNumber the _roomNumber to set
     */
    public void setRoomNumber(String _roomNumber) {
        this._roomNumber = _roomNumber;
    }

    /**
     * @return the _dailyRate
     */
    public double getDailyRate() {
        return _dailyRate;
    }

    /**
     * @param _dailyRate the _dailyRate to set
     */
    public void setDailyRate(double _dailyRate) {
        this._dailyRate = _dailyRate;
    }

    /**
     * @return the _supplies
     */
    public double getSupplies() {
        return _supplies;
    }

    /**
     * @param _supplies the _supplies to set
     */
    public void setSupplies(double _supplies) {
        this._supplies = _supplies;
    }

    /**
     * @return the _services
     */
    public double getServices() {
        return _services;
    }

    /**
     * @param _services the _services to set
     */
    public void setServices(double _services) {
        this._services = _services;
    }

    /**
     * @return the _patientID
     */
    public int getPatientID() {
        return _patientID;
    }

    /**
     * @param _patientID the _patientID to set
     */
    public void setPatientID(int _patientID) {
        this._patientID = _patientID;
    }
    private Date _dateOfStay;
    private String _roomNumber;
    private double _dailyRate;
    private double _supplies;
    private double _services;
    private int _patientID;
 }
