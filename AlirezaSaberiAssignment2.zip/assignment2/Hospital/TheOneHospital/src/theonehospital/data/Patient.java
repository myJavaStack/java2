/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theonehospital.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author alans
 */
public class Patient {

    public Patient(String _lastName, String _firstName, String _diagnosis, Date _admissionDate, Date _relDate) {
        this._lastName = _lastName;
        this._firstName = _firstName;
        this._diagnosis = _diagnosis;
        this._admissionDate = _admissionDate;
        this._releaseDate = _relDate;
    }

    public void PrintPatient(){
        System.out.print("First name: " + _firstName);
        System.out.print(", Last name: " + _lastName);
        System.out.print(", Diagnosis: " + _diagnosis);
        System.out.print(", Admission date: " + _admissionDate);
        System.out.println(", Release date: " + _releaseDate);
    }
    
    @Override
    public boolean equals(Object obj){
        if (obj == null) return false;
        if (obj == this) return true;
        if (!(obj instanceof Patient))return false;

        final Patient other = (Patient) obj;
        if(!other._firstName.equalsIgnoreCase(_firstName) || !other._lastName.equals(_lastName) 
                || !other._diagnosis.equalsIgnoreCase(_diagnosis) || other._releaseDate.getDate() != _releaseDate.getDate()
                || other._admissionDate.getDate() != _admissionDate.getDate()){
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 41 * hash + Objects.hashCode(this._lastName);
        hash = 41 * hash + Objects.hashCode(this._firstName);
        hash = 41 * hash + Objects.hashCode(this._diagnosis);
        hash = 41 * hash + Objects.hashCode(this._admissionDate);
        hash = 41 * hash + Objects.hashCode(this._releaseDate);
        return hash;
    }

    /**
     * @return the _lastName
     */
    public String getLastName() {
        return _lastName;
    }

    /**
     * @param _lastName the _lastName to set
     */
    public void setLastName(String _lastName) {
        this._lastName = _lastName;
    }

    /**
     * @return the _firstName
     */
    public String getFirstName() {
        return _firstName;
    }

    /**
     * @param _firstName the _firstName to set
     */
    public void setFirstName(String _firstName) {
        this._firstName = _firstName;
    }

    /**
     * @return the _diagnosis
     */
    public String getDiagnosis() {
        return _diagnosis;
    }

    /**
     * @param _diagnosis the _diagnosis to set
     */
    public void setDiagnosis(String _diagnosis) {
        this._diagnosis = _diagnosis;
    }

    /**
     * @return the _admissionDate
     */
    public Date getAdmissionDate() {
        return _admissionDate;
    }

    /**
     * @param _admissionDate the _admissionDate to set
     */
    public void setAdmissionDate(Date _admissionDate) {
        this._admissionDate = _admissionDate;
    }

    /**
     * @return the _releaseDate
     */
    public Date getReleaseDate() {
        return _releaseDate;
    }

    /**
     * @param _releaseDate the _releaseDate to set
     */
    public void setReleaseDate(Date _releaseDate) {
        this._releaseDate = _releaseDate;
    }

    public List<Inpatient> getInpatientList() {
        return _inpatientList;
    }

    public List<Medication> getMedList() {
        return _medList;
    }

    public List<Surgical> getSurgicalList() {
        return _surgicalList;
    }
        
    private int _patientID;

    public int getPatientID() {
        return _patientID;
    }

    public void setPatientID(int _patientID) {
        this._patientID = _patientID;
    }
    private String _lastName;
    private String _firstName;
    private String _diagnosis;
    private Date _admissionDate;
    private Date _releaseDate;
    
    private List<Inpatient> _inpatientList = new ArrayList<Inpatient>();

    public void setInpatientList(List<Inpatient> _inpatientList) {
        this._inpatientList = _inpatientList;
    }

    public void setMedList(List<Medication> _medList) {
        this._medList = _medList;
    }

    public void setSurgicalList(List<Surgical> _surgicalList) {
        this._surgicalList = _surgicalList;
    }
    private List<Medication> _medList = new ArrayList<Medication>();
    private List<Surgical> _surgicalList = new ArrayList<Surgical>();
 
}
