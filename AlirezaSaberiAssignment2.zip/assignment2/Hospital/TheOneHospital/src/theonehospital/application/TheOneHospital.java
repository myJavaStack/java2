/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theonehospital.application;

import java.util.Calendar;
import java.util.Date;
import theonehospital.business.HospitalRecordsManager;
import theonehospital.data.Patient;

/**
 *
 * @author alans
 */
public class TheOneHospital {

    private final HospitalRecordsManager hospitalRecordsManager;
    public static final long ONE_DAY_MILLIS = 86400 * 1000;
    
    public TheOneHospital(){
        hospitalRecordsManager = new HospitalRecordsManager();
    }
    
    public void printAllPatientsInfo(){
        hospitalRecordsManager.printAllPatientsInfo();
    }

    public static void main(String[] args) {
        TheOneHospital newHospital = new TheOneHospital();
        
        // Test insert new patient
        /*newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.CreatePatient("Jones", "Nina", 
                "Cyst", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (3 * ONE_DAY_MILLIS)));
        
        // Test retrive patient by id
        Patient retrieved = newHospital.hospitalRecordsManagerr.hospitalDBCRUDHandler.FindPatientByID(1);
        retrieved.PrintPatient();
        
        // Test retrive patient by name
        Patient retrievedByName = newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.FindPatientByName("Barry", "Allen");
        retrievedByName.PrintPatient();
        
        
        // Test add new impatient
        newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.CreateInPatient(new Date(new Date().getTime()), 
                "A22", 112.0, 45.0, 12.0, 5);
        
        // Test add new surgical
        newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.CreateSurgical(new Date(new Date().getTime()), "Cataract surgery", 
                130.0, 120, 5);
        
        // Test add new medical
        newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.CreateMedication(new Date(new Date().getTime()), 
                "CATA2", 10.0, 10, 6);
        
        // Test delete patients
        newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.DeletePatient("Larry", "Wolf");
        
        newHospital.hospitalRecordsManager.printMasterRecordByLastName("Banner");
        
        newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.UpdatePatientsDiagnosis(17, "Heart burn");
        
        newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.UpdatePatientsReleaseDate(17, 
                new Date(new Date().getTime() + (8 * ONE_DAY_MILLIS)));
        
        newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.
                UpdateSurgery(new Date(new Date().getTime()), "Cataract surgery", 112, 90, 5);
        newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.
                UpdateMedication(new Date(new Date().getTime()), "Aero Bar", 11.9, 10, 5);
        newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.
                UpdateInpatient(new Date(new Date().getTime()), "A22", 118.9, 34, 10, 5);*/
        

        /*newHospital.hospitalRecordsManager.printAllSurgical();
        newHospital.hospitalRecordsManager.printAllMedications();
        newHospital.hospitalRecordsManager.printAllInpatients();
        
        newHospital.hospitalRecordsManager.hospitalDBCRUDHandler.DeletePatient("Banner");
        newHospital.hospitalRecordsManager.printAllPatientsInfo();
        
        newHospital.hospitalRecordsManager.printAllSurgical();
        newHospital.hospitalRecordsManager.printAllMedications(); 
        newHospital.hospitalRecordsManager.printAllInpatients(); */
        
        newHospital.hospitalRecordsManager.printAllPatientsInfo();
    }
    
}
