/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theonehospital.business;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import junit.framework.TestCase;
import static junit.framework.TestCase.assertEquals;
import static theonehospital.application.TheOneHospital.ONE_DAY_MILLIS;
import theonehospital.data.Inpatient;
import theonehospital.data.Medication;
import theonehospital.data.Patient;
import theonehospital.data.Surgical;

/**
 *
 * @author alans
 */
public class HospitalDBCRUDHandlerTest extends TestCase {
    
    public HospitalDBCRUDHandlerTest() {
    }
    
    private HospitalDBCRUDHandler hospitalDBCRUDHandler;
    
    @Override
    protected void setUp() throws Exception {
        Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/HOSPITALDB", "hospital", "hospital");
        hospitalDBCRUDHandler = new HospitalDBCRUDHandler(conn);
    }
    
    //Insert a new patient, then retreive via id and compare the results
    public void testCreatePatient_InsertNewPatient_IsInserted(){
        
        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Barry", "Luisa", 
                "Dementia", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (5 * ONE_DAY_MILLIS)));
        Patient found = hospitalDBCRUDHandler.FindPatientByLastName("Barry");
        assertEquals(insertedPatient, found);
    }
    
    //Insert a new patient and a new inpatient for it, then retreive the inpatient via id and compare the results
    public void testCreateInpatient_InsertNewInpatient_IsInserted(){
        
        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Keane", "Jill", 
                "Arithmia", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)));
        
        Inpatient insertedInptient = hospitalDBCRUDHandler.CreateInpatient(new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)), "Z6", 
            110, 66.0, 9.3, insertedPatient.getPatientID());
            
        List<Inpatient> foundList = hospitalDBCRUDHandler.FindInpatientByPatientID(insertedPatient.getPatientID());
        
        assertTrue(foundList.contains(insertedInptient));
    }
    
    //Insert a new patient and a new medication for it, then retreive the medication via id and compare the results
    public void testCreateMedication_InsertNewMedication_IsInserted(){

        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("May", "Jin", 
                "Fever", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)));
        
        Medication med = hospitalDBCRUDHandler.CreateMedication(new Date(new Date().getTime()), 
                "Tylenol", 10.0, 10, insertedPatient.getPatientID());
            
        List<Medication> foundList = hospitalDBCRUDHandler.FindMedicationByPatientID(insertedPatient.getPatientID());
        
        assertTrue(foundList.contains(med));
    }
    
    //Insert a new patient and a new surgery for it, then retreive the inpatient via id and compare the results
    public void testCreateSurgery_InsertNewSurgery_ISInserted(){

        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Watson", "Nina", 
                "Kidney Stone", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)));
        
        Surgical surgery = hospitalDBCRUDHandler.CreateSurgical(new Date(new Date().getTime()), 
                "Stone removal", 11.0, 10, insertedPatient.getPatientID());
            
        List<Surgical> foundList = hospitalDBCRUDHandler.FindSurgicalByPatientID(insertedPatient.getPatientID());
        
        assertTrue(foundList.contains(surgery));
    }
    
    /* Insert a new patient and get the total number of patients
     * Then delete and try to find it, also compare the total number of patient, it must be minus 1 the previous amount
     */
    public void testDeletePatient_DeletePatient_IsDeleted(){
        
        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Rolling", "J.K", 
                "Headache", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)));
        int numOfPatients = hospitalDBCRUDHandler.FindAllPatients().size();
        
        hospitalDBCRUDHandler.DeletePatient("Rolling");
        Patient found = hospitalDBCRUDHandler.FindPatientByLastName("Rolling");
        assertEquals(null, found);
        
        assertEquals(numOfPatients - 1, hospitalDBCRUDHandler.FindAllPatients().size());
    }
    
    public void testUpdatePatient_UpdatePatientsDiagnosisAndRelaseDate_IsUpdated(){
        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Mattison", "Dina", 
                "Brain tumor", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (9 * ONE_DAY_MILLIS)));
        hospitalDBCRUDHandler.UpdatePatientsDiagnosis(insertedPatient.getPatientID(), "Brain Cyst");
        
        Date newReleaseDate = new Date(new Date().getTime() + (5 * ONE_DAY_MILLIS));
        hospitalDBCRUDHandler.UpdatePatientsReleaseDate(insertedPatient.getPatientID(), newReleaseDate);
    
        Patient found = hospitalDBCRUDHandler.FindPatientByID(insertedPatient.getPatientID());
        
        assertEquals(found.getDiagnosis(), "Brain Cyst");
        assertEquals(found.getReleaseDate().getDate(), newReleaseDate.getDate());
    }
    
    /* Insert a new patient and a new impatient for it
     * Then delete the inpatient and try to find it, also compare the total number of inpatients after deletion, 
     * It must be minus 1 the previous amount
     */
    public void testDeleteInpatient_DeleteInpatient_IsDeleted(){
        
        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Fay", "Tina", 
                "Asthma", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)));
        
        Inpatient inpatient = hospitalDBCRUDHandler.CreateInpatient(new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)), "Z6", 
            110, 66.0, 9.3, insertedPatient.getPatientID());
        
        int numOfInpatients = hospitalDBCRUDHandler.FindAllInpatients().size();
        
        hospitalDBCRUDHandler.DeleteInpatient(insertedPatient.getPatientID(), "Z6");
        
        List<Inpatient> found = hospitalDBCRUDHandler.FindInpatientByPatientID(insertedPatient.getPatientID());
        
        assertFalse(found.contains(inpatient));
        
        assertEquals(numOfInpatients - 1, hospitalDBCRUDHandler.FindAllInpatients().size());
    }
    
    public void testUpdateInpatient_UpdateInpatient_IsUpdated(){
        
        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Mandez", "Chris", 
                "Blader stone", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (9 * ONE_DAY_MILLIS)));
        Date dateOfStay = new Date(new Date().getTime() + (1 * ONE_DAY_MILLIS));
        
        Inpatient insertedInptient = hospitalDBCRUDHandler.CreateInpatient(dateOfStay, "Z6", 
            110, 66.0, 9.3, insertedPatient.getPatientID());
        
        hospitalDBCRUDHandler.UpdateInpatient(dateOfStay, "W10", 112, 90.0, 39.3, insertedPatient.getPatientID());
   
        List<Inpatient> foundList = hospitalDBCRUDHandler.FindInpatientByPatientID(insertedPatient.getPatientID());
        
        assertTrue(foundList.contains(new Inpatient(dateOfStay, "W10", 112, 90.0, 39.3, insertedPatient.getPatientID())));
        assertFalse(foundList.contains(insertedInptient));
    }

    
    /* Insert a new patient and a new surgery for it
     * Then delete the surgery and try to find it, also compare the total number of surgeries after deletion, 
     * It must be minus 1 the previous amount
     */
    public void testDeleteSurgical_DeleteSurgical_IsDeleted(){
        
        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Dimitris", "Alex", 
                "Knee injury", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)));
        
        Surgical surgery = hospitalDBCRUDHandler.CreateSurgical(new Date(new Date().getTime()), 
                "Knee repairment", 11.0, 10, insertedPatient.getPatientID());
        
        int numOfSurgeries = hospitalDBCRUDHandler.FindAllSurgicals().size();
        
        hospitalDBCRUDHandler.DeleteSurgical(insertedPatient.getPatientID(), "Knee repairment");
        
        List<Surgical> found = hospitalDBCRUDHandler.FindSurgicalByPatientID(insertedPatient.getPatientID());
        
        assertFalse(found.contains(surgery));
        
        assertEquals(numOfSurgeries - 1, hospitalDBCRUDHandler.FindAllSurgicals().size());
    }
    
        
    public void testUpdateSurgical_UpdateSurgical_IsUpdated(){
        
        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Zane", "Charlie", 
                "Appendicitis", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)));
                    
        Date dateOfSurgery = new Date(new Date().getTime() + (1 * ONE_DAY_MILLIS));
        
        Surgical insertedSurgical = hospitalDBCRUDHandler.CreateSurgical(dateOfSurgery, "Apandix removal", 
            110, 66.0, insertedPatient.getPatientID());
        
        hospitalDBCRUDHandler.UpdateSurgery(dateOfSurgery, "Appendicitis", 23, 230.0, insertedPatient.getPatientID());
   
        List<Surgical> foundList = hospitalDBCRUDHandler.FindSurgicalByPatientID(insertedPatient.getPatientID());
        
        assertTrue(foundList.contains(new Surgical(dateOfSurgery, "Appendicitis", 23, 230.0, insertedPatient.getPatientID())));
        assertFalse(foundList.contains(insertedSurgical));
    }
    
    public void testDeleteMedication_DeleteMedication_IsDeleted(){
        
        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Perry", "Alina", 
                "Head injury", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)));
        
         Medication med = hospitalDBCRUDHandler.CreateMedication(new Date(new Date().getTime()), 
                "Tylenol", 10.0, 10, insertedPatient.getPatientID());
        
        int numOfmeds = hospitalDBCRUDHandler.FindAllMedications().size();
        
        hospitalDBCRUDHandler.DeleteMedication(insertedPatient.getPatientID(), "Tylenol");
        
        List<Medication> found = hospitalDBCRUDHandler.FindMedicationByPatientID(insertedPatient.getPatientID());
        
        assertFalse(found.contains(med));
        
        assertEquals(numOfmeds - 1, hospitalDBCRUDHandler.FindAllMedications().size());
    }
    
    public void testUpdateMedication_UpdateMedication_IsUpdated(){
        
        Patient insertedPatient = hospitalDBCRUDHandler.CreatePatient("Mac", "Milan", 
                "Appendicitis", Calendar.getInstance().getTime(), new Date(new Date().getTime() + (2 * ONE_DAY_MILLIS)));
                    
        Date dateOfMed = new Date(new Date().getTime() + (1 * ONE_DAY_MILLIS));
        
        Medication insertedMedication = hospitalDBCRUDHandler.CreateMedication(dateOfMed, "Antibiotic", 
            110, 66.0, insertedPatient.getPatientID());
        
        hospitalDBCRUDHandler.UpdateMedication(dateOfMed, "Antibiotic ++", 23, 230.0, insertedPatient.getPatientID());
   
        List<Medication> foundList = hospitalDBCRUDHandler.FindMedicationByPatientID(insertedPatient.getPatientID());
        
        assertTrue(foundList.contains(new Medication(dateOfMed, "Antibiotic ++", 23, 230.0, insertedPatient.getPatientID())));
        assertFalse(foundList.contains(insertedMedication));
    }
    
    public void testFindPatient_FindPatientByID_IsFound(){
        Patient found = hospitalDBCRUDHandler.FindPatientByID(1);
        assertTrue(found.getFirstName().equals("Bruce"));
        assertTrue(found.getLastName().equals("Wayne"));
    }
    
    public void testFindPatient_FindPatientByLastName_IsFound(){
        Patient found = hospitalDBCRUDHandler.FindPatientByLastName("Wayne");
        assertTrue(found.getFirstName().equals("Bruce"));
        assertTrue(found.getPatientID() == 1);
    }

}
