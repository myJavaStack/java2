package javaapplication1;

/**
 *
 * @author alans
 */
public class Any7 implements PlayingAny7{
    
    private int totalDiceTemp3 = 0;
    private String any7Result = "";

    public Any7() {
    }
    
     public String getAny7Result() {
        return any7Result;
    }

    public void setAny7Result(String any7Result) {
        this.any7Result = any7Result;
    }

    @Override
    public void playAny7(){
        RollingDice rd = new RollingDice();  
        System.out.println("Rolling the dice...");
        
        for (int i=1; i<=2; i++){
            rd.rollTheDie();
            totalDiceTemp3 += rd.getOneDie();
            System.out.print("Die: " + rd.getOneDie() + " ");
        }
    
        rd.setTotal_Dice(totalDiceTemp3);
        System.out.println("Total is " + rd.getTotal_Dice());
       
        if (rd.getTotal_Dice() == 7){
            rd.setTotal_Dice(0);
            setAny7Result("Won"); 
        } else {  
            rd.setTotal_Dice(0);
            setAny7Result("Lost");           
        }    
    }       
}

