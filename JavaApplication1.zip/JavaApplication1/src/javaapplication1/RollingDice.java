/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Random;

/**
 *
 * @author alans
 */

public class RollingDice implements DoRollingDice {
    
  private int oneDie;
  private int total_Dice=0;
  private int point=0;

    public RollingDice() {
        
    }

    public int getOneDie() {
        return oneDie;
    }

    public int getTotal_Dice() {
        return total_Dice;
    }

    public void setTotal_Dice(int total_Dice) {
        this.total_Dice = total_Dice;
    }

    public int getPoint() {
        return point;
    }

    public void setPoint(int point) {
        this.point = point;
    }
    
    public void rollTheDie(){
    
        Random rand = new Random(); 
        oneDie = rand.nextInt(6) + 1;
    
    }
    
    @Override
    public String toString() {
        return "TheDie{" + "oneDie=" + oneDie + '}';
    }
}


