package javaapplication1;

/**
 *
 * @author alans


*/

public class PassLine implements PlayingPassLine {
    
    private int totalDiceremp1 = 0;
    private int pointtemp = 0;
    private String passLineResult = "";
    public PassLine() {
    }

    public String getPassLineResult() {
        return passLineResult;
    }

    public void setPassLineResult(String passLineResult) {
        this.passLineResult = passLineResult;
    }

    RollingDice rd = new RollingDice();
   Validation va = new Validation();
    
    @Override
    public void playPassLine(){
        System.out.println("Rolling the dice...");
        totalDiceremp1 = 0;
    
        for (int i=1; i<=2; i++){
            rd.rollTheDie();
            totalDiceremp1 += rd.getOneDie();
            System.out.print("Die"+ i + ": "+ rd.getOneDie() + "  ");
        }
        
        rd.setTotal_Dice(totalDiceremp1);
        System.out.println("  ,Total Dice is " + rd.getTotal_Dice());
   
        if (rd.getTotal_Dice() == 7 || rd.getTotal_Dice() == 11) {
            totalDiceremp1 = 0;
            rd.setTotal_Dice(0);
            setPassLineResult("Won");
        } else if(rd.getTotal_Dice() == 2 || rd.getTotal_Dice()== 3 || rd.getTotal_Dice()== 12 ){
            totalDiceremp1 = 0;
            rd.setTotal_Dice(0);
            setPassLineResult("Lost");
        }else {
            rd.setPoint(rd.getTotal_Dice());
            pointtemp = rd.getTotal_Dice();
            System.out.println("Total dice was " + totalDiceremp1 + " which means you neither won or lost.\nThe point is " + 
                        pointtemp + " \nRoll the dice again");
            
            totalDiceremp1 = 0;
            rd.setTotal_Dice(0);
            rd.setPoint(pointtemp);
            setPassLineResult("Point");
        }
    }
    
   
    @Override
    public void pass_Line_Point () throws InvalidMenuException{
        while(true){
        String choiceTemp = "";      
        choiceTemp = va.continiueOrExitMenuValidation();
        if (choiceTemp.equalsIgnoreCase("B")){
            break;
        }
        System.out.println("Rolling the dice...");
        totalDiceremp1 = 0;
        
        for (int i=1; i<=2; i++){
            rd.rollTheDie();
            totalDiceremp1 += rd.getOneDie();
            System.out.print("Die"+ i + ": "+ rd.getOneDie() + "  ");
        }
    
    
        rd.setTotal_Dice(totalDiceremp1);
        System.out.print("Total dice: " + rd.getTotal_Dice() + "  ,Point: " + pointtemp);
    
        if(rd.getTotal_Dice() == rd.getPoint()){
            rd.setTotal_Dice(0);
            rd.setPoint(0);
            setPassLineResult("Won"); 
            break;
        
        }else if (totalDiceremp1 == 7){
            rd.setTotal_Dice(0);
            rd.setPoint(0);
            setPassLineResult("Lost");
            break;
         }else{
             System.out.println("\nThe total dice was neither equals to the point ,which is " + rd.getPoint() + 
                        ", to win nor equals to 7 to lose.\nRoll the dice again");
     
            setPassLineResult("Point");
        }
    
        }
    }
    
    }
    
    


