
package javaapplication1;

/**
 *
 * @author alans
 */

public class FieldBet implements PlayingFieldBet{
    
    private int totalDiceTemp2 = 0;
    private String fieldBetResults = "";

    public FieldBet() {
    }

    public String getFieldBetResults() {
        return fieldBetResults;
    }

    public void setFieldBetResults(String fieldBetResults) {
        this.fieldBetResults = fieldBetResults;
    }
    
    
    @Override
    public void playFieldBet(){
        RollingDice rd = new RollingDice();
        totalDiceTemp2 = 0;
        System.out.println("Rolling the dice...");
        for (int i=1; i<=2; i++){
            rd.rollTheDie();
            totalDiceTemp2 += rd.getOneDie();
            System.out.print("Die: " + rd.getOneDie() + " ");
        }
    
        rd.setTotal_Dice(totalDiceTemp2);
        System.out.println("Total is " + rd.getTotal_Dice());
    
        if (rd.getTotal_Dice() == 3 || rd.getTotal_Dice()==4 || 
            rd.getTotal_Dice()==9 || rd.getTotal_Dice()==10 ||
            rd.getTotal_Dice()== 11) {
                
                rd.setTotal_Dice(0);
                setFieldBetResults("WonBet");
   
        }else if (rd.getTotal_Dice() == 2){
            setFieldBetResults("Won2Bet");
            rd.setTotal_Dice(0);
        
        }else if (rd.getTotal_Dice() == 12){
            setFieldBetResults("Won3Bet");
            rd.setTotal_Dice(0);
        }else { 
            rd.setTotal_Dice(0);
            setFieldBetResults("Lost");
        }
    }   
}

